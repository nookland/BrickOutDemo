﻿using UnityEngine;
using System.Collections;


public class BallScript : MonoBehaviour 
{
	public float speed = 3.0f;
	public GameObject ball2;
	public GameObject ball1;
	public Transform racket;
	bool startBall = true;
	// Use this for initialization
	void Start () 
	{
		Rigidbody2D rb = GetComponent<Rigidbody2D>();
		rb.velocity = Vector2.one * speed;
	}
	
	// Update is called once per frame
	void Update () 
	{
		Rigidbody2D rb = GetComponent<Rigidbody2D> ();

		float yBall = GetComponent<Rigidbody2D>( ).position.y;	//stores the y position of ball in yBall

		if (Input.GetKeyDown("space") && startBall == false)	//will start the ball again after being stopped
		{
			startBall = true;
			rb.velocity = Vector2.one * speed;
		}

		if (yBall < -1.9) //if the yPosition is less than -1.9.. (goes past racket)
		{ 
			startBall = false;
			print ("ball passed");
			GameManager.lives--;
			transform.position = new Vector2 (0, -.5f);
			GetComponent<Rigidbody2D>( ).velocity = Vector2.zero;
			if (GameManager.lives == 2) 
			{
				Destroy (ball2);

			}
			if (GameManager.lives == 1) 
			{
				Destroy (ball1);

			}
			if (GameManager.lives == 0) 
			{
				//gameover

			}
		}

			//instantiate new ball

		//Vector2 s = GetComponent<Rigidbody2D> ();

		/*if ( Input.GetButtonDown( "Fire1" ) )
		{
			transform.parent = null;
			GetComponent<Rigidbody>( ).isKinematic = 
				false;
			GetComponent<Rigidbody>( ).AddForce( new Vector3( speed, speed, 0f ) );
		}*/

	}
}
